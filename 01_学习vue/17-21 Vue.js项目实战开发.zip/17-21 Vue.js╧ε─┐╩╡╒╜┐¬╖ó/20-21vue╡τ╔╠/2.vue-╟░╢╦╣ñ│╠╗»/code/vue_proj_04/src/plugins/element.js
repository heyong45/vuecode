import Vue from 'vue'
import { Button } from 'element-ui'

Vue.use(Button)

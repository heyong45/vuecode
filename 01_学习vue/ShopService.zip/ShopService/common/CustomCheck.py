from django.http import JsonResponse
from common import AuthToken
from common import ResultData

# 检查消息是否已鉴权
def CustomResponse(func):
    def wrapper(request):
        auth = request.META.get("HTTP_AUTHORIZATION")
        auth_flag = AuthToken.check_token(auth)
        if not auth_flag:
            print("auth check failed.")
            ResultData.unauth("auth failed")
        print(auth)
        data = None
        message = ""
        try:
            data = func(request)
            return ResultData.result(data = data)
        except Exception as e:
            return ResultData.server_error(e)
    return wrapper
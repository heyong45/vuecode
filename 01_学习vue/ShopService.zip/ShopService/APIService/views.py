from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
# Create your views here.
from common.CustomCheck import *

@CustomResponse
def login(request):
    print("hello")
    data={
        "data":{
            
        },
        "meta":{
            "message":'success',
            "status":200
        }
    }
    return JsonResponse(data)
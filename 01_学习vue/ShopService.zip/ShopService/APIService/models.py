# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class SpAttribute(models.Model):
    attr_id = models.SmallAutoField(primary_key=True)
    attr_name = models.CharField(max_length=32)
    cat_id = models.PositiveSmallIntegerField()
    attr_sel = models.CharField(max_length=4)
    attr_write = models.CharField(max_length=6)
    attr_vals = models.TextField()
    delete_time = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_attribute'


class SpCategory(models.Model):
    cat_id = models.AutoField(primary_key=True)
    cat_name = models.CharField(max_length=255, blank=True, null=True)
    cat_pid = models.IntegerField(blank=True, null=True)
    cat_level = models.IntegerField(blank=True, null=True)
    cat_deleted = models.IntegerField(blank=True, null=True)
    cat_icon = models.CharField(max_length=255, blank=True, null=True)
    cat_src = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_category'


class SpConsignee(models.Model):
    cgn_id = models.AutoField(primary_key=True)
    user_id = models.IntegerField()
    cgn_name = models.CharField(max_length=32)
    cgn_address = models.CharField(max_length=200)
    cgn_tel = models.CharField(max_length=20)
    cgn_code = models.CharField(max_length=6)
    delete_time = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_consignee'


class SpExpress(models.Model):
    express_id = models.AutoField(primary_key=True)
    order_id = models.PositiveIntegerField()
    express_com = models.CharField(max_length=32, blank=True, null=True)
    express_nu = models.CharField(max_length=32, blank=True, null=True)
    create_time = models.PositiveIntegerField()
    update_time = models.PositiveIntegerField()

    class Meta:
        managed = False
        db_table = 'sp_express'


class SpGoods(models.Model):
    goods_id = models.AutoField(primary_key=True)
    goods_name = models.CharField(unique=True, max_length=255)
    goods_price = models.DecimalField(max_digits=10, decimal_places=2)
    goods_number = models.PositiveIntegerField()
    goods_weight = models.PositiveSmallIntegerField()
    cat_id = models.PositiveSmallIntegerField()
    goods_introduce = models.TextField(blank=True, null=True)
    goods_big_logo = models.CharField(max_length=128)
    goods_small_logo = models.CharField(max_length=128)
    is_del = models.CharField(max_length=1)
    add_time = models.IntegerField()
    upd_time = models.IntegerField()
    delete_time = models.IntegerField(blank=True, null=True)
    cat_one_id = models.SmallIntegerField(blank=True, null=True)
    cat_two_id = models.SmallIntegerField(blank=True, null=True)
    cat_three_id = models.SmallIntegerField(blank=True, null=True)
    hot_mumber = models.PositiveIntegerField(blank=True, null=True)
    is_promote = models.SmallIntegerField(blank=True, null=True)
    goods_state = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_goods'


class SpGoodsAttr(models.Model):
    goods_id = models.PositiveIntegerField()
    attr_id = models.PositiveSmallIntegerField()
    attr_value = models.TextField()
    add_price = models.DecimalField(max_digits=8, decimal_places=2, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_goods_attr'


class SpGoodsCats(models.Model):
    cat_id = models.AutoField(primary_key=True)
    parent_id = models.IntegerField()
    cat_name = models.CharField(max_length=50)
    is_show = models.IntegerField()
    cat_sort = models.IntegerField()
    data_flag = models.IntegerField()
    create_time = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'sp_goods_cats'


class SpGoodsPics(models.Model):
    pics_id = models.AutoField(primary_key=True)
    goods_id = models.PositiveIntegerField()
    pics_big = models.CharField(max_length=128)
    pics_mid = models.CharField(max_length=128)
    pics_sma = models.CharField(max_length=128)

    class Meta:
        managed = False
        db_table = 'sp_goods_pics'


class SpManager(models.Model):
    mg_id = models.AutoField(primary_key=True)
    mg_name = models.CharField(max_length=32)
    mg_pwd = models.CharField(max_length=128)
    mg_time = models.PositiveIntegerField()
    role_id = models.IntegerField()
    mg_mobile = models.CharField(max_length=32, blank=True, null=True)
    mg_email = models.CharField(max_length=64, blank=True, null=True)
    mg_state = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_manager'


class SpOrder(models.Model):
    order_id = models.AutoField(primary_key=True)
    user_id = models.PositiveIntegerField()
    order_number = models.CharField(unique=True, max_length=32)
    order_price = models.DecimalField(max_digits=10, decimal_places=2)
    order_pay = models.CharField(max_length=1)
    is_send = models.CharField(max_length=1)
    trade_no = models.CharField(max_length=32)
    order_fapiao_title = models.CharField(max_length=2)
    order_fapiao_company = models.CharField(max_length=32)
    order_fapiao_content = models.CharField(max_length=32)
    consignee_addr = models.TextField()
    pay_status = models.CharField(max_length=1)
    create_time = models.PositiveIntegerField()
    update_time = models.PositiveIntegerField()

    class Meta:
        managed = False
        db_table = 'sp_order'


class SpOrderGoods(models.Model):
    order_id = models.PositiveIntegerField()
    goods_id = models.PositiveIntegerField()
    goods_price = models.DecimalField(max_digits=10, decimal_places=2)
    goods_number = models.IntegerField()
    goods_total_price = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        managed = False
        db_table = 'sp_order_goods'


class SpPermission(models.Model):
    ps_id = models.SmallAutoField(primary_key=True)
    ps_name = models.CharField(max_length=20)
    ps_pid = models.PositiveSmallIntegerField()
    ps_c = models.CharField(max_length=32)
    ps_a = models.CharField(max_length=32)
    ps_level = models.CharField(max_length=1)

    class Meta:
        managed = False
        db_table = 'sp_permission'


class SpPermissionApi(models.Model):
    ps_id = models.IntegerField()
    ps_api_service = models.CharField(max_length=255, blank=True, null=True)
    ps_api_action = models.CharField(max_length=255, blank=True, null=True)
    ps_api_path = models.CharField(max_length=255, blank=True, null=True)
    ps_api_order = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_permission_api'


class SpReport1(models.Model):
    rp1_user_count = models.IntegerField(blank=True, null=True)
    rp1_area = models.CharField(max_length=128, blank=True, null=True)
    rp1_date = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_report_1'


class SpReport2(models.Model):
    rp2_page = models.CharField(max_length=128, blank=True, null=True)
    rp2_count = models.IntegerField(blank=True, null=True)
    rp2_date = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_report_2'


class SpReport3(models.Model):
    rp3_src = models.CharField(max_length=127, blank=True, null=True)
    rp3_count = models.IntegerField(blank=True, null=True)
    rp3_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_report_3'


class SpRole(models.Model):
    role_id = models.SmallAutoField(primary_key=True)
    role_name = models.CharField(max_length=20)
    ps_ids = models.CharField(max_length=512)
    ps_ca = models.TextField(blank=True, null=True)
    role_desc = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_role'


class SpType(models.Model):
    type_id = models.SmallAutoField(primary_key=True)
    type_name = models.CharField(max_length=32)
    delete_time = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_type'


class SpUser(models.Model):
    user_id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=128)
    qq_open_id = models.CharField(max_length=32, blank=True, null=True)
    password = models.CharField(max_length=64)
    user_email = models.CharField(max_length=64)
    user_email_code = models.CharField(max_length=13, blank=True, null=True)
    is_active = models.CharField(max_length=1, blank=True, null=True)
    user_sex = models.CharField(max_length=2)
    user_qq = models.CharField(max_length=32)
    user_tel = models.CharField(max_length=32)
    user_xueli = models.CharField(max_length=2)
    user_hobby = models.CharField(max_length=32)
    user_introduce = models.TextField(blank=True, null=True)
    create_time = models.IntegerField()
    update_time = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'sp_user'


class SpUserCart(models.Model):
    cart_id = models.AutoField(primary_key=True)
    user_id = models.PositiveIntegerField()
    cart_info = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(blank=True, null=True)
    delete_time = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sp_user_cart'

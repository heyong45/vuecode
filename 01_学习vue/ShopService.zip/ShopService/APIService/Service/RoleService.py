from APIService import models
from django.forms.models import model_to_dict
from django.core import serializers

def get_primission_keys():
    permissionKeys = {}
    sql = "SELECT * FROM sp_permission_api as api LEFT JOIN sp_permission as main ON main.ps_id = api.ps_id WHERE main.ps_id is not null"
    permission_list = models.SpPermissionApi.objects.raw(sql)
    for permission_item in permission_list:
        item_dict = permission_item.__dict__
        item_dict.pop('_state')
        permissionKeys[permission_item.ps_id] = item_dict
    return permissionKeys
def get_role_list():
    result_data = []
    permissionKeys = get_primission_keys()
    for role_item in models.SpRole.objects.all():
        permissionIds = role_item.ps_ids.split(',')
        child_item = get_role_permiss(permissionKeys,permissionIds)
        role = {
            "id": role_item.role_id,
            "roleName": role_item.role_name,
            "roleDesc": role_item.role_desc,
            "children": child_item
        }
        result_data.append(role)
    return result_data
def get_role_permiss(permissionKeys,permissionIds):
    permissionsResult = {}
    for idx in permissionIds:
        print(idx)
        if idx== '0' or idx == "":
            continue

        permissionId = int(idx)
        permission = permissionKeys[permissionId]
        if permission and permission['ps_level'] == '0':
            permissionsResult[permission['ps_id']] = {
            "id":permission['ps_id'],
            "authName": permission['ps_name'],
            "path": permission['ps_api_path'],
            "children": []
            }

    tmpResult = {}
    for idx in permissionIds:
        if idx== '0' or idx == "":
            continue
        permissionId = int(idx)
        permission = permissionKeys[permissionId]
        if permission and permission['ps_level'] == '1':
            if permission['ps_pid'] not in permissionsResult:
                continue
            parentPermissionResult = permissionsResult[permission['ps_pid']]
            if parentPermissionResult:
                tmpResult[permission['ps_id']] = {
                    "id":permission['ps_id'],
                    "authName": permission['ps_name'],
                    "path": permission['ps_api_path'],
                    "children": []
                }
                parentPermissionResult['children'].append(tmpResult[permission['ps_id']])

    # 处理三级菜单
    for idx in permissionIds:
        if idx== '0' or idx == "":
            continue
        permissionId = int(idx)
        permission = permissionKeys[permissionId];
        if permission and permission['ps_level'] == '2':
            if permission['ps_pid'] not in tmpResult:
                continue
            parentPermissionResult = tmpResult[permission['ps_pid']]
            if parentPermissionResult:
                parentPermissionResult['children'].append({
                    "id":permission['ps_id'],
                    "authName": permission['ps_name'],
                    "path": permission['ps_api_path']
                });

    return permissionsResult

def get_role_by_id(id):
    role = models.SpRole.objects.get(role_id=id)
    return {
        "roleId": role.role_id,
        "roleName": role.role_name,
        "roleDesc": role.role_desc,
        "rolePermissionDesc": role.ps_ca
    }

def modify_role(param):
    id = param.get("id")
    roleName = param.get("roleName")
    roleDesc = param.get("roleDesc")
    role = models.SpRole.objects.get(role_id=id)
    role.role_name = roleName
    role.role_desc = roleDesc
    role.save()


def delete_role_by_id(id):
    role = models.SpRole.objects.get(role_id=id)
    role.delete()

def add_role(param):
    role = models.SpRole()
    roleName = param.get("roleName")
    roleDesc = param.get("roleDesc")
    role.role_name = roleName
    role.role_desc = roleDesc
    role.save()


def delete_role_right_by_id(id,right_id):
    role = models.SpRole.objects.get(role_id=id)
    right_str = role.ps_ids
    tmp_right_list = right_str.split(',')
    tmp_right_list.remove(right_id)
    right_new_str = ','.join(tmp_right_list)
    role.ps_ids = right_new_str
    role.save()
    permissionKeys = get_primission_keys()
    return get_role_permiss(permissionKeys, tmp_right_list)
from APIService import models
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core import serializers
import json

#前台普通用户列表
def get_user_list(query,pagenum,pagesize):
    sql = "SELECT * FROM sp_manager as mgr LEFT JOIN sp_role as role ON mgr.role_id = role.role_id";
    if query:
        sql = sql + " mg_name like %s"%query
    user_list = []
    for item in  models.SpManager.objects.raw(sql):
        role_name = item.role_name;
        if item.role_id == 0:
            role_name = "超级管理员"
        user_list.append({
            "id":item.mg_id,
            "username": item.mg_name,
            "role_name":role_name,
            "create_time":item.mg_time,
            "mobile": item.mg_mobile,
            "email":item.mg_email,
            "mg_state":item.mg_state == 1
        })
    paginator = Paginator(user_list, pagesize)
    resultDta = {}
    resultDta["total"] = paginator.count;
    resultDta["pagenum"] = pagenum;

    users = []
    try:
        users = paginator.page(pagenum)
    except PageNotAnInteger:
        users = paginator.page(1)
    except EmptyPage:
        users = paginator.page(paginator.num_pages)
    resultDta["users"] =  users.object_list
    return resultDta
from APIService import models

def get_list():
    result = []
    sql = "SELECT * FROM sp_permission_api as api LEFT JOIN sp_permission as main ON main.ps_id = api.ps_id WHERE main.ps_id is not null"
    permission_list = models.SpPermissionApi.objects.raw(sql)
    for permission in permission_list:
        result.append({
            "id": permission.ps_id,
            "authName": permission.ps_name,
            "level": permission.ps_level,
            "pid": permission.ps_pid,
            "path": permission.ps_api_path
        })

    return result

def get_tree():
    permissionKeys = {}
    sql = "SELECT * FROM sp_permission_api as api LEFT JOIN sp_permission as main ON main.ps_id = api.ps_id WHERE main.ps_id is not null"
    permission_list = models.SpPermissionApi.objects.raw(sql)
    for permission_item in permission_list:
        item_dict = permission_item.__dict__
        item_dict.pop('_state')
        permissionKeys[permission_item.ps_id] = item_dict

    # 显示一级
    permissionsResult = {}
    # 处理一级菜单
    for permission in permission_list:
        if permission.ps_level == '0':
            permissionsResult[permission.ps_id] = {
                "id":permission.ps_id,
                "authName": permission.ps_name,
                "path": permission.ps_api_path,
                "pid": permission.ps_pid,
                "children": []
            }

    # 临时存储二级返回结果
    tmpResult = {};
    # 处理二级菜单
    for permission in permission_list:
        if permission.ps_level == '1':
            if permission.ps_pid not in permissionsResult:
                continue
            parentPermissionResult = permissionsResult[permission.ps_pid];
            if parentPermissionResult:
                tmpResult[permission.ps_id] = {
                    "id":permission.ps_id,
                    "authName": permission.ps_name,
                    "path": permission.ps_api_path,
                    "pid": permission.ps_pid,
                    "children": []
                }
                parentPermissionResult['children'].append(tmpResult[permission.ps_id])

    # 处理三级菜单
    for permission in permission_list:
        if permission.ps_level == '2':
            if permission.ps_pid not in tmpResult:
                continue
            parentPermissionResult = tmpResult[permission.ps_pid];
            if parentPermissionResult:
                parentPermissionResult['children'].append({
                    "id":permission.ps_id,
                    "authName": permission.ps_name,
                    "path": permission.ps_api_path,
                    "pid": str(permission.ps_pid) + "," + str(permissionKeys[permission.ps_pid]['ps_pid'])
                })
    return permissionsResult
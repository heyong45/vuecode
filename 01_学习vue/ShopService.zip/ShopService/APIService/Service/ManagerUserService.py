from django.contrib.auth.hashers import make_password, check_password
import base64
from APIService import models
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import time
# 添加用户
def add_user(param):
    pwd =base64.b64encode(bytes(make_password(param.get("password")),'utf-8')).decode()
    obj = models.SpManager()
    obj.mg_name = param.get("username")
    obj.mg_mobile = param.get("mobile")
    obj.mg_email = param.get("email")
    obj.mg_pwd = pwd
    obj.role_id = 0
    obj.mg_state = 0
    obj.mg_time = int(time.time())
    obj.save()
    return


#查询管理员用户
def get_user_list(query,pagenum,pagesize):
    sql = "SELECT * FROM sp_manager as mgr LEFT JOIN sp_role as role ON mgr.role_id = role.role_id"
    if query:
        sql = """SELECT * FROM sp_manager as mgr LEFT JOIN sp_role as role ON mgr.role_id = role.role_id where mg_name like "%%{0}%%" """.format(query)
    user_list = []
    for item in  models.SpManager.objects.raw(sql):
        role_name = item.role_name;
        if item.role_id == 0:
            role_name = "超级管理员"
        user_list.append({
            "id":item.mg_id,
            "username": item.mg_name,
            "role_name":role_name,
            "create_time":item.mg_time,
            "mobile": item.mg_mobile,
            "email":item.mg_email,
            "mg_state":item.mg_state == 1
        })
    paginator = Paginator(user_list, pagesize)
    resultDta = {}
    resultDta["total"] = paginator.count;
    resultDta["pagenum"] = pagenum;

    users = []
    try:
        users = paginator.page(pagenum)
    except PageNotAnInteger:
        users = paginator.page(1)
    except EmptyPage:
        users = paginator.page(paginator.num_pages)
    resultDta["users"] =  users.object_list
    return resultDta


def modify_user(userInfo):
    obj = models.SpManager.objects.get(mg_id = userInfo.get("id"))
    if "mobile" in userInfo:
        obj.mg_mobile = userInfo.get("mobile")
    if "email" in userInfo:
        obj.mg_email = userInfo.get("email")
    if "mg_state" in userInfo:
        if userInfo.get("mg_state"):
            obj.mg_state =1
        else:
            obj.mg_state = 0
    if "rid" in userInfo:
        obj.role_id = userInfo.get("rid")
    obj.save()


def get_user_by_id (id):
    obj = models.SpManager.objects.get(mg_id = id)

    data = {
            "id":obj.mg_id,
            "username": obj.mg_name,
            "create_time":obj.mg_time,
            "mobile": obj.mg_mobile,
            "email":obj.mg_email,
            "mg_state":obj.mg_state == 1
        }
    return data

def delete_user_by_id(id):
    obj = models.SpManager.objects.get(mg_id=id)
    obj.delete()
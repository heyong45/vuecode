from django.contrib.auth.hashers import make_password, check_password
from APIService import models
import base64

def login(user,password):
    msg = ""
    w = make_password(password)
    s =base64.b64encode(bytes(w,'utf-8')).decode()
    obj = models.SpManager.objects.get(mg_name = user)

    if not obj:
        msg = "用户不存在"
        return msg, None

    r_pwd = base64.b64decode(obj.mg_pwd).decode()
    if not check_password(password, r_pwd):
        msg = "密码错误"
        return msg,None

    data = {
            "id":obj.mg_id,
            "rid":obj.role_id,
            "username":obj.mg_name,
            "mobile":obj.mg_mobile,
            "email":obj.mg_email,
        }
    return "",data

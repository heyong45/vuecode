from APIService import models

def get_left_menu(username):
    obj = models.SpManager.objects.get(mg_name = username)
    rid = obj.role_id
    permissions = models.SpPermission.objects.raw("SELECT * FROM sp_permission_api as api LEFT JOIN sp_permission as main ON main.ps_id = api.ps_id WHERE main.ps_id is not null")
    rootPermissionsResult = {}
    for permission in permissions:
        if permission.ps_level == '0' :
            rootPermissionsResult[permission.ps_id] = {
                "id": permission.ps_id,
                "authName": permission.ps_name,
                "path": permission.ps_api_path,
                "children": [],
                "order": permission.ps_api_order
            }

    for permission in permissions:
        if permission.ps_level == '1':
            parentPermissionResult = rootPermissionsResult[permission.ps_pid];
            if parentPermissionResult:
                parentPermissionResult["children"].append({
                "id":permission.ps_id,
                "authName": permission.ps_name,
                "path": permission.ps_api_path,
                "children": [],
                "order": permission.ps_api_order
                })
    return rootPermissionsResult
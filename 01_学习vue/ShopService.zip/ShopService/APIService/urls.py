"""ShopService URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path,re_path
from APIService import views
from APIService.API import login
from APIService.API import menus
from APIService.API import user
from APIService.API import role
from APIService.API import right

urlpatterns = [
    path('login', login.login),
    path('menus', menus.menus),
    path('users', user.user),
    re_path('users/query', user.query_user_by_id),
    path('roles', role.role),
    path('roles/id', role.get_role_by_id),
    path('roles/delright', role.delete_role_right_by_id),
    path('rights/tree',right.get_tree),
    path('rights/list',right.get_list)
]

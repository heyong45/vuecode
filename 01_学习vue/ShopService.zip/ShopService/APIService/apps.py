from django.apps import AppConfig


class ApiserviceConfig(AppConfig):
    name = 'APIService'

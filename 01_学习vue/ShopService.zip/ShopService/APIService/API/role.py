from common.CustomCheck import *
from APIService.Service import RoleService
import json
@CustomResponse
def role(request):
    if request.method == "GET":
        query = request.GET.get("query","")
        return RoleService.get_role_list()
    if request.method == "PUT":
        param = json.loads(request.body)
        return RoleService.modify_role(param)
    if request.method == "DELETE":
        id = request.GET.get("id", "")
        return RoleService.delete_role_by_id(id)
    if request.method == 'POST':
        param = json.loads(request.body)
        return RoleService.add_role(param)

@CustomResponse
def get_role_by_id(request):
    if request.method == "GET":
        id = request.GET.get("id","")
        return RoleService.get_role_by_id(id)

@CustomResponse
def delete_role_right_by_id(request):
    if request.method == "DELETE":
        id = request.GET.get("id", "")
        right_id = request.GET.get("rightId", "")
        return RoleService.delete_role_right_by_id(id, right_id)
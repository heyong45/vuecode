from django.http import JsonResponse
from common import AuthToken
from APIService.Service import LoginService
import json

def login(request):
    param = json.loads(request.body)
    username = param.get("username")
    password = param.get("password")

    msg ,data = LoginService.login(username,password)
    status = 200
    if data is None:
        status = 201
    token = AuthToken.create_token(username)
    data["token"] = token
    result = {
        "data":data,
        "meta":{
            "msg":msg,
            "status":status
        }
    }
    return JsonResponse(result)

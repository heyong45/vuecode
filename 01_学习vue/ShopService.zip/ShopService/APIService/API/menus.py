from common.CustomCheck import *
from common import AuthToken
from APIService.Service import MenuService
@CustomResponse
def menus(request):
    print("hello")
    token = request.META.get("HTTP_AUTHORIZATION")
    username = AuthToken.get_username(token)
    data = MenuService.get_left_menu(username)
    return data
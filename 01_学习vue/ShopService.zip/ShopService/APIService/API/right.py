from common.CustomCheck import *
from APIService.Service import RightService
import json


@CustomResponse
def get_tree(request):
    return RightService.get_tree()

@CustomResponse
def get_list(request):
    return RightService.get_list()
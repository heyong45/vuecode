from common.CustomCheck import *
import json
from APIService.Service import ManagerUserService
@CustomResponse
def user(request):
    if request.method == "GET":
        query = request.GET.get("query","")
        pagenum = request.GET.get("pagenum",1)
        pagesize = request.GET.get("pagesize",5)
        return ManagerUserService.get_user_list(query,pagenum,pagesize)
    if request.method == 'POST':
        param = json.loads(request.body)
        return ManagerUserService.add_user(param)
    if request.method == "PUT":
        param = json.loads(request.body)
        return ManagerUserService.modify_user(param)
    if request.method == "DELETE":
        id = request.GET.get("id", "")
        return ManagerUserService.delete_user_by_id(id)

@CustomResponse
def query_user_by_id(request):
    if request.method == "GET":
        id = request.GET.get("id", "")
        return ManagerUserService.get_user_by_id(id)